SELECT 
    *
FROM
    log_reg.register;


SELECT 
    *
FROM
    register
WHERE
    register.id = (3);

SELECT 
    *
FROM
    register
WHERE
    register.email = (1);


INSERT INTO log_reg.register (first_name , last_name , email , password)
VALUES ("john", "Doe", "yo@gmail.com", "214")


