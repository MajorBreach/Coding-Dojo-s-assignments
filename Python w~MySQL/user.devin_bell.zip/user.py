class BankAccount:

    bank_name = PNClams
    accounts = []

    def __init__(self, int_rate, balance, amount):
        self.int_rate = int_rate
        self.balance = balance

    def deposit(self, amount):
        self.balance

    def withdraw(self, amount):
        # your code here

    def display_account_info(self):
        # your code here

    def yield_interest(self):
        # your code here


PNClams = BankAccount(0.1, 0, 0)
print(self);
