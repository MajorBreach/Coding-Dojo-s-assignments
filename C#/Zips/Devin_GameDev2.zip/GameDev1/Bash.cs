

public class Attack
{
    public string Name;
    public int Dmg;
    public Attack(string name, int dmg)
    {
        Name = name;
        Dmg = dmg;
    }
}