﻿
Attack Crasher = new Attack("crasher",100);
Attack WK = new Attack("Wheel Kick",90);
Attack FB = new Attack("Furious Bash", 80);


Enemy Creant = new Enemy("Tauren");


Creant.AddAttack(Crasher);
Creant.AddAttack(WK);
Creant.AddAttack(FB);
Creant.RandAttack();

