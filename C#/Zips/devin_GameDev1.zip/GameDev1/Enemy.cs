
public class Enemy
{
    public List<Attack> SkillList = new List<Attack>();
    public string Name;
    public int HP = 300;
    public Enemy(string name, int hp = 300)
    {
        Name = name;
        HP = hp;
    }

    public void RandAttack()
    {
        if (SkillList.Count > 0)
        {
            Random random = new Random();
            int idx = random.Next(0, SkillList.Count);
            Attack bash = SkillList[idx];
            System.Console.WriteLine($"{Name} Picked {bash.Name} and Savaged for {bash.Dmg} to Me");
        }
        else
        {
            System.Console.WriteLine("Missed");
        }
    }
    public void AddAttack(Attack bash)
    {
        SkillList.Add(bash);
    }
}