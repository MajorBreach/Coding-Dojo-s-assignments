﻿// Three Basic Arrays
int[] numsarry = new int[10];
{
    int s = 0;
    int e = 9;
    int c = 0;
    for (int i = s; i <= e; i++)
    {
        numsarry[i] = c;
        c = c + 1;
    }
    foreach (int x in numsarry)
    {
        System.Console.WriteLine($"{x}");
    }
}
{
    string[] names = new string[] { "Tim", "Martin", "Nikki", "Sara" };
    for (int i = 0; i < names.Length; i++)
    {
        System.Console.WriteLine(names);
    }
}
{
    bool[] arr = new bool[10];
    int s = 0;
    int e = arr.Length;
    for (int i = s; i < e; i += 2)
        {
        arr[i] = true;
        arr[i + 1] = false;
        }
    foreach (bool x in arr)
    {
        System.Console.WriteLine($"{x}");
    }
}




// List of Flavors
{
    List<string> Icecream = new List<string>();
    Icecream.Add("Van");
    Icecream.Add("straw");
    Icecream.Add("choco");
    Icecream.Add("cookie");
    Icecream.Add("oreo");

    System.Console.WriteLine(Icecream.Count);
    System.Console.WriteLine(Icecream[3]);
    Icecream.RemoveAt(3);
    System.Console.WriteLine(Icecream.Count);
}

// User Dictionary
{

    string[] names = new string[] { "Tim", "Martin", "Nikki", "Sara" };
    List<string> Icecream = new List<string>();
    Icecream.Add("Van");
    Icecream.Add("straw");
    Icecream.Add("choco");
    Icecream.Add("cookie");
    Icecream.Add("oreo");
    Dictionary<string, string> profile = new Dictionary<string, string>();
    foreach (var name in names)
    {
        profile.Add(name, null);
    }
    Random rand = new Random();
    foreach (var name in names)
    {
        int randI = rand.Next(Icecream.Count);
        profile[name] = Icecream[randI];
        Icecream.RemoveAt(randI);
    }
    foreach (var entry in profile)
    {
        System.Console.WriteLine("{0} loves {1}", entry.Key, entry.Value);
    }
}