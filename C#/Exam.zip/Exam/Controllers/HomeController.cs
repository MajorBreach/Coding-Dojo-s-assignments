﻿using System.Diagnostics;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Exam.Models;



namespace Exam.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;
    private MyContext _context;
    public HomeController(ILogger<HomeController> logger, MyContext context)
    {
        _logger = logger;
        _context = context;
    }

    // Index +++++++++++++++++++++++++++
        [HttpGet("/")]
    public IActionResult Index()
    {
        return View("Index");
    }


    // User Login/Reg ++++++++++++++++++++++++++++
    [HttpPost("/login")]
    public IActionResult Login(Login userlog)
    {
        if (ModelState.IsValid)
        {
            User? userInDb = _context.Users.FirstOrDefault(u => u.Email == userlog.UserEmail);
            if (userInDb == null)
            {
                ModelState.AddModelError("Email", "invaild Email/Password");
                return Index();
            }
            PasswordHasher<Login> hasher = new PasswordHasher<Login>();
            var result = hasher.VerifyHashedPassword(userlog, userInDb.Password, userlog.UserPassword);
            if (result == 0)
            {
                ModelState.AddModelError("Email", "invaild Email/Password");
                return View("Index");
            }
            HttpContext.Session.SetInt32("UserId", userInDb.UserId);
            HttpContext.Session.SetString("UserName", userInDb.UserName);
            return ViewAll();
        }
        return View("Index");
    }

    [HttpPost("/register")]
    public IActionResult Register(User newUser)
    {
        if (ModelState.IsValid)
        {
            PasswordHasher<User> Hasher = new PasswordHasher<User>();
            newUser.Password = Hasher.HashPassword(newUser, newUser.Password);
            _context.Add(newUser);
            _context.SaveChanges();
            HttpContext.Session.SetInt32("UserId", newUser.UserId);
            HttpContext.Session.SetString("UserName", newUser.UserName);
            return ViewAll();
        }
        else
        {
            return View("Index");
        }
    }

    [HttpGet("/logout")]
    public IActionResult Logout()
    {
        HttpContext.Session.Clear();
        return View("Index");
    }

//Main Routes+++++++++++++++++++++++++

    [HttpGet("/coupons")]
    public IActionResult ViewAll()
    {
        ViewBag.AllCoupons = _context.Coupons.Include(c=>c.Peoples).Include(c => c.User).ToList();
        return View("Dashboard");
    }

    [HttpPost("/coupons/newCoupon")]
    public IActionResult createCoupon(Coupon newCoupon)
    {
        newCoupon.UserId = (int)HttpContext.Session.GetInt32("UserId");
        if (ModelState.IsValid)
        {
            _context.Add(newCoupon);
            _context.SaveChanges();
            int createCouponID = newCoupon.CouponId;
            return RedirectToAction("ViewAll", new {CouponId = createCouponID});
        }
        else
        {
            return NewCoupon();
        }
    }


    
    [HttpGet("/coupon/new")]
    public IActionResult NewCoupon()
    {
        return View("Create");
    }


    [HttpPost("/coupon/{CouponId}/update")]
    public IActionResult UseCoupon(People addPerson, int Id)
    {
        addPerson.CouponId = Id;
        addPerson.UserId = (int)HttpContext.Session.GetInt32("UserId");
        _context.Add(addPerson);
        _context.SaveChanges();
        return RedirectToAction("ViewAll");
    }


    [HttpGet("/coupon/{CouponId}")]
    public IActionResult Viewone(int CouponId)
    {
        UseView OneCoupon = new UseView
        {
            Coupon = _context.Coupons.FirstOrDefault(a =>a.CouponId == CouponId),
            AllPeople = _context.Peoples
            .Include(u => u.User)
            .Include(c => c.Coupon)
            .Where(c => c.CouponId == CouponId).ToList()
        };
        return View("ShowOne",OneCoupon);
    }










            //Stop Here, End routes====================
        public IActionResult Privacy()
        {
            return View();
        }



    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
