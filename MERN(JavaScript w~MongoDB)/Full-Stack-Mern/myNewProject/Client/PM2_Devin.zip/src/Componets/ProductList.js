import React from 'react'
import axios from 'axios';
    
const ProductList = (props) => {
    return (
        <div>
            {props.Form.map( (Form, i) =>
                <p key={i}>{Form.Title}, {Form.Price}, {Form.Description}</p>
            )}
        </div>
    )
}
    
export default ProductList;

