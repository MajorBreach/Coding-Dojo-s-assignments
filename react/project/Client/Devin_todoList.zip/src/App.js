
import { useState } from 'react';
import './App.css';

function App() {

  const [newTodo, setNewToDo] = useState("");
  const [todos, setTodos] = useState([]);
  
  const handleNewTodoSubmit = (e) => {
    e.preventDefault();
    setTodos([...todos, todolist]);
    setNewToDo("")
  }

  const handletodosdelete = (value) => {
    const filter = todos.filter((todos,index)=>{
      return index !== value;
    });
    setTodos(filter)
  };

  const todolist = {
    text: newTodo,
    done : false,
  }
  
  const handlecomplete = (index) =>{
    const updated = todos.map((todos,i) =>{
      if (index === i){
        todos.complete = !todos.complete;
    }
      return todos;
    });
    setTodos(updated);
  }



  return (
    <div className="App">

      <form onSubmit ={(e) => {
        handleNewTodoSubmit(e);
      }}>
        <input value = {newTodo} type = "text" onChange={(e) => {
          setNewToDo(e.target.value)
          
        }}/>
        <div>
        <button>add</button>
        </div>
      </form>

      {todos.map((todos, index) =>{
        const todosClasses = [""]
        if(todos.complete){
          todosClasses.push("line-through");
        }

        return (<div key = {index}>
          <input onChange={(e)=>{
            handlecomplete(index);
          }} checked ={todos.complete}  type = "checkbox" ></input>
          
          
          <span className={todosClasses.join(" ")}>{todos.text}</span>
          <button onClick={(e) =>{
          handletodosdelete(index);
          }}>delete</button>
        </div>
        );
      })}
    </div>
  );
}

export default App;
