import React, { Component } from 'react';


class Display extends Component {
    constructor(props){
        super(props);


        this.state = {
            name: props.name,
            Age: props.Age,
            Hcolor:props.Hcolor,
        };

    }
    Incrementage = ()=>{
        this.setState({Age:this.state.Age + 1});
    }



    render() {
        const{name, Age, Hcolor} = this.state;
        return (
        <div>
            <h1>{name}</h1>
            <p>Age: {Age}</p>
            <p>Hair color: {Hcolor}</p>
            <button onClick ={this.Incrementage}>Birthday button for {name}</button>
        </div>
        );
    }
}
    
export default Display;