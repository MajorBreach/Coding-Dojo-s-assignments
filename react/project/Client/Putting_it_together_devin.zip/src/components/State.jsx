// import React, { Component } from "react";

// class State extends Component {
//     render() {
//         return (
//             <div>
//                 <h1>{this.props.name}</h1>
//                 <p>{this.props.Age}</p>
//                 <p>{this.props.Hcolor}</p>
//             </div>
//         );
//     }
// }

// export default State;