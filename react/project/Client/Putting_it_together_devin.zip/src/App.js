
import './App.css';


import Display from './components/Display';
function App() {
  return (
    <div className="App">
      <Display name = 'Doe,Jane' Age = {45} Hcolor= "Black" />
      
      <Display name = 'Smith,John' Age ={88} Hcolor= "Brown"/>
    </div>
  );
}

export default App;
