
import './App.css';
import Display from './components/Display';

function App() {
  return (
    <div className="App">
      <Display>
      </Display>
      
      
      
      
    </div>
  );
}

export default App;
