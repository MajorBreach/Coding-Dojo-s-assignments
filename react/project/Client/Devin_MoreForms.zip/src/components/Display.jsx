import React, { useState } from 'react';


const UserForm = (props) => {
    const [state, setState] = useState({
        username : props.username,
        email : props.email,
        password: props.password,
        conpassword:props.conpassword,
    });


    const [username, setUsername] = useState(props.username);
    const [email, setEmail] = useState(props.email);
    const [password, setPassword] = useState(props.password);
    const [conpassword, setConPassword] = useState(props.conpassword);
    const [nameError, setNameError] = useState ("");
    const [emailError, setEmailError] = useState ("");
    const [passwordError, setPasswordError] = useState ("");
    const [conpasswordError, setConPasswordError] = useState ("");



    const User = (e) => {
        e.preventDefault();
        const newUser = { username, email, password,conpassword };
        console.log(newUser);
        

    setState({
        ...state,
        username : username,
        email : email,
        password : password,
        conpassword : password,

    });
        setUsername("")
        setEmail("")
        setPassword("")
        setConPassword("")
    };
    const handleUser = (e) =>{
        setUsername(e.target.value);
        if( e.target.value.length< 2){
        setNameError("username must be atleast 2 characters");
    } else {
        setNameError("");
    }
    }
    const handleEmail = (e) =>{
        setEmail(e.target.value);
        if( e.target.value.length< 5){
        setEmailError("Email must be at least 5 characters");
    } else {
        setEmailError("");
    }
    }
    const handlePassword = (e) =>{
        setPassword(e.target.value);
        if( e.target.value.length< 8){
        setPasswordError("Password must be atleast 8 characters");
    } else {
        setPasswordError("");
    }
    }
    const handleConPassword = (e) =>{
        setConPassword(e.target.value);
        if( password !== conpassword ){
            setConPasswordError("");
        } else {
        setConPasswordError("Passwords must match!");
        }
    }
    return (
        <form onSubmit={User}>
            

            <div>
                <label>Username: </label>
                <input type="text" onChange={handleUser}value ={username} />
                {
                    nameError ?
                    <p>{nameError}</p>:
                    ''
                }
            </div>
            <div>
                <label>Email Address: </label>
                <input type="text" onChange={handleEmail} value ={email} />
                {
                    emailError ?
                    <p>{emailError}</p>:
                    ''
                }
            </div>
            <div>
                <div>
                {
                    passwordError ?
                    <p>{passwordError}</p>:
                    ''
                }
                <label>Password: </label>
                <input type="text" onChange={handlePassword} value ={password} />
                </div>
                <div>
                <label>Confirm Password: </label>
                <input type="text" onChange={handleConPassword} value ={conpassword} />
                {
                    conpasswordError ?
                    <p>{conpasswordError}</p>:
                    ''
                }
                </div>
            </div>
            <input type="submit" value="Create User" />
            <div>
                <p>{state.username}</p>
                <p>{state.email}</p>
                <p>{state.password}</p>
                <p>{state.conpassword}</p>
            </div>
        </form>

    );
};

export default UserForm;