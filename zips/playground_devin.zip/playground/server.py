from flask import Flask, render_template
app = Flask(__name__)

@app.route("/")
def default_page():
    return "<h1>You're in the wrong place ,  Try: http://127.0.0.1:5000/play</h1>"

@app.route('/play')
def one():
    
    
    return render_template( 'playground.html', times = 3 , color = "red")


@app.route('/play/<int:times>')
def second(times):
    print(times)
    
    return render_template('playground.html',times=times , color = "blue")

app.route('/play/<int:times>/<string:color>')
def third(times,color):
    
    
    return render_template('playground.html',times=times , color = color)


if __name__=="__main__":
    app.run(debug=True)