SELECT * FROM dojos_ninja.ninjas;
select first_name from dojos_ninja.ninjas where dojos_id = 5;
select first_name from dojos_ninja.ninjas where dojos_id = 6;
select first_name from dojos_ninja.ninjas where dojos_id = 7;
