from flask import Flask, render_template, request, session,  redirect 
app = Flask(__name__)
app.secret_key = "watsittoya"
#anthony helped

@app.route("/")
def first():
    return render_template("survey.html")

@app.route('/result')
def result():
    return render_template("result.html")


@app.route('/form', methods=['POST'])
def processing():
    session['name'] = request.form['name']
    session['dojo_location'] = request.form['dojo_location']
    session['language'] = request.form['language']
    session['comment'] = request.form['comment']
    return redirect('/result')


if __name__ == "__main__":
        app.run(debug=True)
