from flask import Flask, render_template, redirect, session
app = Flask(__name__)
app.secret_key = 'hi mom'

# import session 
@app.route('/')
def first():
    if 'count' not in session:
        session['count'] = 1
    else:
        session['count'] += 1
    return render_template("counter.html")

# pwn
@app.route('/destroy')
def pwn():
    session.clear()
    return redirect('/')


if __name__ == '__main__':
    app.run(debug=True)
